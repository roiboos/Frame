pycomfoconnect
==============

!! This library is deprecated and is replaced by https://github.com/michaelarnauts/aiocomfoconnect. !!

A Python library to interface with the Zehnder ComfoConnect LAN C bridge that is connected to the Zehnder ComfoAir Q350/450/600 ventilation units.

Installation
------------

::

    pip3 install pycomfoconnect
